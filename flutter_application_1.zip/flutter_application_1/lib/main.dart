// lib/main.dart
import 'package:flutter/material.dart';

// Note model
class Note {
  String id;
  String title;
  String description;
  DateTime createdAt;

  Note({
    required this.id,
    required this.title,
    required this.description,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();
}

void main() {
  runApp(MyApp());
}

final Color brandOrange = Color(0xFFF57C00);
final Color darkBg = Color(0xFF263238);
final Color cardBg = Color(0xFF2E3A3F);

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final base = ThemeData.dark();
    return MaterialApp(
      title: 'Flutter Notes App',
      debugShowCheckedModeBanner: false,
      theme: base.copyWith(
        scaffoldBackgroundColor: Color(0xFF1F2A30),
        colorScheme: base.colorScheme.copyWith(
          primary: brandOrange,
          secondary: brandOrange,
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: brandOrange,
            textStyle: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: cardBg,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          hintStyle: TextStyle(color: Colors.grey[400]),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: brandOrange,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: EdgeInsets.symmetric(vertical: 16),
            textStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => LoginScreen(),
      },
    );
  }
}

// ---------------- Login Screen ----------------
class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _controller = TextEditingController(text: '');
  String? _error;

  void _login() {
    final id = _controller.text.trim();
    if (id.isEmpty) {
      setState(() => _error = 'Please enter a user ID');
      return;
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => DashboardScreen(userId: id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: width * 0.08, vertical: 40),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: 420),
              child: Column(
                children: [
                  Icon(Icons.local_fire_department, size: 92, color: brandOrange),
                  SizedBox(height: 18),
                  Text(
                    'Flutter Notes App',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 28),
                  Container(
                    padding: EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: darkBg,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black54,
                          blurRadius: 12,
                          offset: Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'User ID',
                            style: TextStyle(color: Colors.grey[300], fontSize: 14),
                          ),
                        ),
                        SizedBox(height: 8),
                        TextField(
                          controller: _controller,
                          keyboardType: TextInputType.text,
                          style: TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'Enter your user ID',
                          ),
                          onChanged: (_) {
                            if (_error != null) setState(() => _error = null);
                          },
                        ),
                        if (_error != null) ...[
                          SizedBox(height: 8),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(_error!, style: TextStyle(color: Colors.redAccent)),
                          ),
                        ],
                        SizedBox(height: 18),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: Icon(Icons.login, color: Colors.white),
                            label: Text(
                              'LOGIN TO YOUR ACCOUNT',
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: _login,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


// ---------------- Dashboard Screen ----------------
class DashboardScreen extends StatefulWidget {
  final String userId;
  DashboardScreen({required this.userId});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<Note> notes = [];

  @override
  void initState() {
    super.initState();
    notes = [
      Note(
        id: '1',
        title: 'Flutter Description',
        description: 'Flutter is Google\'s UI toolkit for building beautiful apps.',
      ),
      Note(
        id: '2',
        title: 'First Note',
        description: 'Hello world, welcome to Flutter Notes App.',
      ),
    ];
  }

  void _openAdd() async {
    final Note? created = await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AddScreen()),
    );
    if (created != null) setState(() => notes.insert(0, created));
  }

  void _openEdit(Note note) async {
    final result = await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => EditScreen(note: note)),
    );
    if (result == null) return;

    if (result is Map) {
      final action = result['action'];
      if (action == 'update' && result['note'] is Note) {
        final Note updated = result['note'];
        setState(() {
          final idx = notes.indexWhere((n) => n.id == updated.id);
          if (idx != -1) notes[idx] = updated;
        });
      } else if (action == 'delete' && result['id'] != null) {
        setState(() {
          notes.removeWhere((n) => n.id == result['id']);
        });
      }
    }
  }

  Widget _buildNoteCard(Note note) {
    return Card(
      color: cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        title: Text(note.title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6.0),
          child: Text(
            note.description,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: Colors.grey[300]),
          ),
        ),
        trailing: Icon(Icons.chevron_right, color: Colors.grey[400]),
        onTap: () => _openEdit(note),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Icon(Icons.local_fire_department, color: brandOrange),
          SizedBox(width: 8),
          Text('Flutter Notes', style: TextStyle(color: Colors.white)),
        ]),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            tooltip: 'Logout',
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => LoginScreen()));
            },
            icon: Icon(Icons.logout),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          child: Column(
            children: [
              if (notes.isEmpty) ...[
                Expanded(
                  child: Center(
                    child: Text(
                      'No notes yet.\nTap the + button to add a new note.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey[400], fontSize: 16),
                    ),
                  ),
                )
              ] else ...[
                Expanded(
                  child: ListView.separated(
                    itemCount: notes.length,
                    separatorBuilder: (_, __) => SizedBox(height: 12),
                    itemBuilder: (_, i) => _buildNoteCard(notes[i]),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: brandOrange,
        onPressed: _openAdd,
        icon: Icon(Icons.add, color: Colors.white),
        label: Text('Add Note', style: TextStyle(color: Colors.white)),
      ),
    );
  }
}

// ---------------- AddScreen ----------------
class AddScreen extends StatefulWidget {
  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _saving = false;

  void _addNote() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final newNote = Note(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
    );

    Navigator.of(context).pop(newNote);
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Note', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: width * 0.05, vertical: 18),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleCtrl,
                  decoration: InputDecoration(
                    labelText: 'Title',
                    hintText: 'Enter note title',
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Enter a title' : null,
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _descCtrl,
                  decoration: InputDecoration(
                    labelText: 'Description',
                    hintText: 'Enter note description',
                  ),
                  maxLines: null,
                  minLines: 6,
                  validator: (v) => v == null || v.trim().isEmpty ? 'Enter a description' : null,
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.add, color: Colors.white),
                    label: Text('Add Note', style: TextStyle(color: Colors.white)),
                    onPressed: _saving ? null : _addNote,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------- EditScreen ----------------
class EditScreen extends StatefulWidget {
  final Note note;
  EditScreen({required this.note});

  @override
  State<EditScreen> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  final _formKey = GlobalKey<FormState>();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.note.title);
    _descCtrl = TextEditingController(text: widget.note.description);
  }

  void _updateNote() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final updated = Note(
      id: widget.note.id,
      title: _titleCtrl.text.trim(),
      description: _descCtrl.text.trim(),
      createdAt: widget.note.createdAt,
    );

    Navigator.of(context).pop({'action': 'update', 'note': updated});
  }

  void _deleteNote() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Delete note?'),
        content: Text('This will remove the note permanently.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop({'action': 'delete', 'id': widget.note.id});
            },
            child: Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Note', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: width * 0.05, vertical: 18),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleCtrl,
                  decoration: InputDecoration(
                    labelText: 'Title',
                    hintText: 'Enter note title',
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Enter a title' : null,
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _descCtrl,
                  decoration: InputDecoration(
                    labelText: 'Description',
                    hintText: 'Enter note description',
                  ),
                  maxLines: null,
                  minLines: 6,
                  validator: (v) => v == null || v.trim().isEmpty ? 'Enter a description' : null,
                  style: TextStyle(color: Colors.white),
                ),
                SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: Icon(Icons.save, color: Colors.white),
                        label: Text('Update Note', style: TextStyle(color: Colors.white)),
                        onPressed: _saving ? null : _updateNote,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        icon: Icon(Icons.delete, color: Colors.white),
                        label: Text('Delete Note', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                        onPressed: _deleteNote,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
